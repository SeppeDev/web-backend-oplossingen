<?php if(count($delete) > 0): ?>
    <!-- Form Delete List -->
    <div class="bg-danger clearfix">   

	    <?php if($delete->content): ?>

	    	Are you sure you want to delete this comment?

	    	<form action="<?php echo e(url('comment/deleteNow/'.$delete->id)); ?>" method="POST" class="pull-right">
	            <?php echo e(csrf_field()); ?>


	            <input type="hidden" name="_method" value="DELETE">
	            <input type="hidden" name="comment" value="<?php echo e($delete); ?>">

	            <button name="delete" class="btn btn-danger" value="<?php echo e($delete->id); ?>">
	                <i class="fa fa-btn fa-trash" title="delete"></i> confirm delete
	            </button>

	            <button name="cancel" class="btn" value="<?php echo e($delete->id); ?>">
	                <i class="fa fa-btn fa-trash" title="cancel"></i> cancel
	            </button>

	        </form>

	    <?php else: ?>

	    	Are you sure you want to delete this article?

	    	<form action="<?php echo e(url('article/deleteNow/'.$delete->id)); ?>" method="POST" class="pull-right">
	            <?php echo e(csrf_field()); ?>


	            <input type="hidden" name="_method" value="DELETE">
	            <input type="hidden" name="article" value="<?php echo e($delete); ?>">

	            <button name="delete" class="btn btn-danger" value="<?php echo e($delete->id); ?>">
	                <i class="fa fa-btn fa-trash" title="delete"></i> confirm delete
	            </button>

	            <button name="cancel" class="btn" value="<?php echo e($delete->id); ?>">
	                <i class="fa fa-btn fa-trash" title="cancel"></i> cancel
	            </button>

	        </form>

	    <?php endif; ?>

    </div>
<?php endif; ?>