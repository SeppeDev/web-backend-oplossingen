<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">

            <!-- Bootstrap Boilerplate... -->

            <!-- Display Validation Errors -->
            <?php echo $__env->make('common.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('common.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="breadcrumb">

                <a href="<?php echo e(url('/')); ?>">← back to overview</a>
            </div>

            <div class="panel panel-default">

                <div class="panel-heading">Article: <?php echo e($article->title); ?>


                    <?php if(Auth::check()): ?>

                        <?php if($article->user_id == Auth::user()->id): ?>

                            <a href="<?php echo e(url('/article/delete/'.$article->id)); ?>" class="btn btn-danger btn-xs pull-right">
                                <i class="fa fa-btn fa-trash" title="delete"></i> delete article
                            </a>

                        <?php endif; ?>

                    <?php endif; ?>

                </div>

                <div class="panel-content">

                    <ul class="article-overview">
                        <li>

                            <div class="vote">

                                    <?php if(Auth::check()): ?>
                                        
                                        <?php $canVote = true ?>

                                        <?php if($article->user_id == Auth::user()->id): ?>
                                        
                                            <div class="form-inline upvote">

                                                <i class="fa fa-btn fa-caret-up disabled upvote" title="You cant upvote your own articles"></i>

                                            </div>

                                        <?php else: ?>
                                        
                                            <?php foreach($votes as $vote): ?>

                                                <?php if(Auth::user()->id == $vote->user_id && $article->id == $vote->article_id && $vote->vote == true): ?>

                                                    <div class="form-inline upvote">

                                                        <i class="fa fa-btn fa-caret-up disabled upvote" title="You can only upvote once"></i>

                                                    </div>

                                                    <?php $canVote = false ?>

                                                <?php endif; ?>

                                            <?php endforeach; ?>

                                            <?php if($canVote): ?>

                                                <form action="<?php echo e(url('/vote/up/'.$article->id)); ?>" method="POST" class="form-inline upvote">
                                                    <?php echo csrf_field(); ?>


                                                    <button>

                                                        <i class="fa fa-btn fa-caret-up" title="upvote"></i>

                                                    </button>

                                                </form>

                                            <?php endif; ?>

                                        <?php endif; ?>

                                    <?php else: ?>

                                        <div class="form-inline upvote">

                                            <i class="fa fa-btn fa-caret-up disabled upvote" title="You need to be logged in to upvote"></i>

                                        </div>

                                    <?php endif; ?>

                                    <?php if(Auth::check()): ?>

                                        <?php $canVote = true ?>

                                        <?php if($article->user_id == Auth::user()->id): ?>
                                        
                                            <div class="form-inline upvote">

                                                <i class="fa fa-btn fa-caret-down disabled upvote" title="You cant downvote your own articles"></i>

                                            </div>

                                        <?php else: ?>
                                        
                                            <?php foreach($votes as $vote): ?>

                                                <?php if(Auth::user()->id == $vote->user_id && $article->id == $vote->article_id && $vote->vote == false): ?>

                                                    <div class="form-inline downvote">

                                                        <i class="fa fa-btn fa-caret-down disabled downvote" title="You can only downvote once"></i>

                                                    </div>

                                                    <?php $canVote = false ?>
                                                    
                                                <?php endif; ?>

                                            <?php endforeach; ?>

                                            <?php if($canVote): ?>

                                                <form action="<?php echo e(url('/vote/down/'.$article->id)); ?>" method="POST" class="form-inline downvote">
                                                    <?php echo csrf_field(); ?>


                                                    <button>

                                                        <i class="fa fa-btn fa-caret-down" title="downvote"></i>

                                                    </button>

                                                </form>

                                            <?php endif; ?>

                                        <?php endif; ?>

                                    <?php else: ?>

                                        <div class="form-inline upvote">

                                            <i class="fa fa-btn fa-caret-down disabled downvote" title="You need to be logged in to downvote"></i>

                                        </div>

                                    <?php endif; ?>

                                </div>

                            <div class="url">

                                <a href="<?php echo e($article->url); ?>" class="urlTitle"><?php echo e($article->title); ?></a>

                                <?php if(Auth::check()): ?>

                                    <?php if($article->user_id == Auth::user()->id): ?>

                                        <a href="<?php echo e(url('/article/edit/'.$article->id)); ?>" class ="btn btn-primary btn-xs edit-btn">edit</a>

                                    <?php endif; ?>

                                <?php endif; ?>

                            </div>

                            <div class="info">
                            
                                <?php echo e($points[$article->id]); ?>


                                points

                                | 

                                posted by

                                <?php foreach($users as $user): ?>
                                    <?php if($user->id == $article->user_id): ?>
                                        <?php echo e($user->name); ?>

                                    <?php endif; ?>
                                <?php endforeach; ?>

                                |
 
                                <?php echo e($comments->where('article_id', $article->id)->count()); ?>

                                comments

                            </div>

                            <div class="comments">
                            
                                <ul>

                                <?php $hasComments = false ?>

                                    <?php foreach($comments as $comment): ?>

                                        <li>

                                            <div class="comment-body"><?php echo e($comment->content); ?></div>

                                            <div class="comment-info">

                                                Posted by

                                                <?php foreach($users as $user): ?>
                                                    <?php if($user->id == $comment->user_id): ?>
                                                        <?php echo e($user->name); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; ?>

                                                on

                                                <?php echo e($comment->updated_at); ?>


                                                <?php if(Auth::check()): ?>

                                                    <?php if($comment->user_id == Auth::user()->id): ?>

                                                        <a href="<?php echo e(url('/comment/edit/'.$comment->id)); ?>" class ="btn btn-primary btn-xs edit-btn">edit</a>

                                                        <a href="<?php echo e(url('/comment/delete/'.$comment->id)); ?>" class="btn btn-danger btn-xs">
                                                            <i class="fa fa-btn fa-trash" title="delete"></i> delete
                                                        </a>

                                                    <?php endif; ?>

                                                <?php endif; ?>

                                            </div>

                                        </li>

                                        <?php $hasComments = true ?>

                                    <?php endforeach; ?>

                                </ul>

                                <?php if($hasComments == false): ?>

                                    No comments yet

                                <?php endif; ?>

                                <?php if(Auth::guest()): ?>

                                    <p>You need to be <a href="<?php echo e(url('/login')); ?>">logged in</a> to comment</p>

                                <?php endif; ?>

                            </div>

                        </li>
                    </ul>
                </div>

                <?php if(Auth::check()): ?>

                    <form action="<?php echo e(url('comments/add')); ?>" method="POST" class="form-horizontal">

                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">

                            <label for="content" class="col-sm-3 control-label">Comment</label>

                            <div class="col-sm-6">

                                <textarea type="text" name="content" id="content" class="form-control"></textarea>
                            
                            </div>

                        </div>

                        <input type="hidden" name="article_id" value="<?php echo e($article->id); ?>">

                        <div class="form-group">

                            <div class="col-sm-offset-3 col-sm-6">

                                <button type="submit" class="btn btn-default">
                                    <i class="fa fa-plus"></i> Add Comment
                                </button>

                            </div>

                        </div>

                    </form>

                <?php endif; ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>