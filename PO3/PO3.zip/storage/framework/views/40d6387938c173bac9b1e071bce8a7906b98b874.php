<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">

            <!-- Display Validation Errors -->
            <?php echo $__env->make('common.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('common.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
            <div class="panel panel-default">
                <div class="panel-heading">Articles Overview</div>

                <div class="panel-content">

                    <ul class="article-overview">
                        <?php foreach($articles as $article): ?>
                            <li>

                                <div class="vote">

                                    <?php if(Auth::check()): ?>
                                        
                                        <?php $canVote = true ?>

                                        <?php if($article->user_id == Auth::user()->id): ?>
                                        
                                            <div class="form-inline upvote">

                                                <i class="fa fa-btn fa-caret-up disabled upvote" title="You cant upvote your own articles"></i>

                                            </div>

                                        <?php else: ?>
                                        
                                            <?php foreach($votes as $vote): ?>

                                                <?php if(Auth::user()->id == $vote->user_id && $article->id == $vote->article_id && $vote->vote == true): ?>

                                                    <div class="form-inline upvote">

                                                        <i class="fa fa-btn fa-caret-up disabled upvote" title="You can only upvote once"></i>

                                                    </div>

                                                    <?php $canVote = false ?>

                                                <?php endif; ?>

                                            <?php endforeach; ?>

                                            <?php if($canVote): ?>

                                                <form action="<?php echo e(url('/vote/up/'.$article->id)); ?>" method="POST" class="form-inline upvote">
                                                    <?php echo csrf_field(); ?>


                                                    <button>

                                                        <i class="fa fa-btn fa-caret-up" title="upvote"></i>

                                                    </button>

                                                </form>

                                            <?php endif; ?>

                                        <?php endif; ?>

                                    <?php else: ?>

                                        <div class="form-inline upvote">

                                            <i class="fa fa-btn fa-caret-up disabled upvote" title="You need to be logged in to upvote"></i>

                                        </div>

                                    <?php endif; ?>

                                    <?php if(Auth::check()): ?>

                                        <?php $canVote = true ?>

                                        <?php if($article->user_id == Auth::user()->id): ?>
                                        
                                            <div class="form-inline upvote">

                                                <i class="fa fa-btn fa-caret-down disabled upvote" title="You cant downvote your own articles"></i>

                                            </div>

                                        <?php else: ?>
                                        
                                            <?php foreach($votes as $vote): ?>

                                                <?php if(Auth::user()->id == $vote->user_id && $article->id == $vote->article_id && $vote->vote == false): ?>

                                                    <div class="form-inline downvote">

                                                        <i class="fa fa-btn fa-caret-down disabled downvote" title="You can only downvote once"></i>

                                                    </div>

                                                    <?php $canVote = false ?>
                                                    
                                                <?php endif; ?>

                                            <?php endforeach; ?>

                                            <?php if($canVote): ?>

                                                <form action="<?php echo e(url('/vote/down/'.$article->id)); ?>" method="POST" class="form-inline downvote">
                                                    <?php echo csrf_field(); ?>


                                                    <button>

                                                        <i class="fa fa-btn fa-caret-down" title="downvote"></i>

                                                    </button>

                                                </form>

                                            <?php endif; ?>

                                        <?php endif; ?>

                                    <?php else: ?>

                                        <div class="form-inline upvote">

                                            <i class="fa fa-btn fa-caret-down disabled downvote" title="You need to be logged in to downvote"></i>

                                        </div>

                                    <?php endif; ?>

                                </div>

                                <div class="url">

                                    <a href="<?php echo e($article->url); ?>" class="urlTitle"><?php echo e($article->title); ?></a>

                                    <?php if(Auth::check()): ?>

                                        <?php if($article->user_id == Auth::user()->id): ?>

                                            <a href="<?php echo e(url('/article/edit/'.$article->id)); ?>" class ="btn btn-primary btn-xs edit-btn">edit</a>

                                            <a href="<?php echo e(url('/article/delete/'.$article->id)); ?>" class="btn btn-danger btn-xs">
                                                <i class="fa fa-btn fa-trash" title="delete"></i> delete article
                                            </a>

                                        <?php endif; ?>

                                    <?php endif; ?>

                                </div>

                                <div class="info">
                                
                                    <?php echo e($points[$article->id]); ?>


                                    points

                                    |

                                    posted by

                                     <?php foreach($users as $user): ?>
                                        <?php if($user->id == $article->user_id): ?>
                                            <?php echo e($user->name); ?>

                                        <?php endif; ?>
                                     <?php endforeach; ?>

                                    |

                                     <a href="<?php echo e(url('/comments/'.$article->id)); ?>">   
                                        <?php echo e($comments->where('article_id', $article->id)->count()); ?>


                                     comments</a>

                                </div>

                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>